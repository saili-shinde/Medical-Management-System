drop database if exists db_medical;
create database if not exists db_medical;
use db_medical;

create table if not exists medicines
(
m_id int unsigned primary key auto_increment,
med_name varchar(100) unique not null,
availability int unsigned,
price float unsigned not null
);
desc medicines;


create table if not exists customers
(
c_id int unsigned primary key auto_increment,
c_name varchar(100) not null,
c_contact varchar(20) not null,
med_name varchar(100),
quantity int unsigned not null,
paid float unsigned,
pending float unsigned,
foreign key(med_name) references medicines(med_name) on delete set null
);
desc customers;


delimiter $$


drop trigger if exists med_t1 $$
create trigger med_t1 before insert on medicines for each row
begin
	if (new.m_id is null) or (new.m_id<1) then
		signal SQLSTATE '10101' set message_text="m_id can not be null or <1";
	end if;

	if (new.med_name is null) or (length(trim(new.med_name))<2) or (not new.med_name regexp "^[A-Za-z ]+$") then
		signal SQLSTATE '10102' set message_text="med_name can not be null or blank or single letter and can not contain special characters or numbers";
	end if;

	if (new.availability<0) then
		signal SQLSTATE '10103' set message_text="availability can not be -ve";
	end if;

	if (new.price is null) or (new.price<1) then
		signal SQLSTATE '10104' set message_text="price can not be null or <1";
	end if;
end $$

drop trigger if exists med_t2 $$
create trigger med_t2 before update on medicines for each row
begin
	if (new.m_id is null) or (new.m_id<1) then
		signal SQLSTATE '10201' set message_text="m_id can not be null or <1";
	end if;

	if (new.med_name is null) or (length(trim(new.med_name))<2) or (not new.med_name regexp "^[A-Za-z ]+$") then
		signal SQLSTATE '10202' set message_text="med_name can not be null or blank or single letter and can not contain special characters or numbers";
	end if;

	if (new.availability<0) then
		signal SQLSTATE '10203' set message_text="availability can not be -ve";
	end if;

	if (new.price is null) or (new.price<1) then
		signal SQLSTATE '10204' set message_text="price can not be null or <1";
	end if;
end $$


drop trigger if exists cstmr_t1 $$
create trigger cstmr_t1 before insert on customers for each row
begin
	if (new.c_id is null) or (new.c_id<1) then
		signal SQLSTATE '20101' set message_text="c_id can not be null or <1";
	end if;

	if (new.c_name is null) or (length(trim(new.c_name))<2) or (not new.c_name regexp "^[A-Za-z ]+$") then
		signal SQLSTATE '20102' set message_text="c_name can not be null or blank or single letter and can not contain special characters or numbers";
	end if;

	if (new.c_contact is null) or (length(trim(new.c_contact))<10) or (length(trim(new.c_contact))>12) or (not new.c_contact regexp "^[0-9]+$") then
		signal SQLSTATE '20103' set message_text="invalid contact no.";
	end if;

	if (length(trim(new.med_name))<2) or (not new.med_name regexp "^[A-Za-z ]+$") then
		signal SQLSTATE '20104' set message_text="med_name can not be null or blank or single letter and can not contain special characters or numbers";
	end if;

	if (new.quantity is null) or (new.quantity<1) then
		signal SQLSTATE '20105' set message_text="quantity can not be null or  <1";
	end if;

	if (new.paid<0) then
		signal SQLSTATE '20106' set message_text="paid can not be -ve";
	end if;

	if (new.pending<0) then
		signal SQLSTATE '20107' set message_text="pending can not be -ve";
	end if;

	if (new.paid is null) and (new.pending is null) then
		signal SQLSTATE '20108' set message_text="paid and pending can not be null at the same times";
	end if;

end $$

drop trigger if exists cstmr_t2 $$
create trigger cstmr_t2 before update on customers for each row
begin
	if (new.c_id is null) or (new.c_id<1) then
		signal SQLSTATE '20201' set message_text="c_id can not be null or <1";
	end if;

	if (new.c_name is null) or (length(trim(new.c_name))<2) or (not new.c_name regexp "^[A-Za-z ]+$") then
		signal SQLSTATE '20202' set message_text="c_name can not be null or blank or single letter and can not contain special characters or numbers";
	end if;

	if (new.c_contact is null) or (length(trim(new.c_contact))<10) or (length(trim(new.c_contact))>12) or (not new.c_contact regexp "^[0-9]+$") then
		signal SQLSTATE '20203' set message_text="invalid contact no.";
	end if;

	if (length(trim(new.med_name))<2) or (not new.med_name regexp "^[A-Za-z ]+$") then
		signal SQLSTATE '20204' set message_text="med_name can not be null or blank or single letter and can not contain special characters or numbers";
	end if;

	if (new.quantity<1) then
		signal SQLSTATE '20205' set message_text="quantity can not be <1";
	end if;

	if (new.paid<0) then
		signal SQLSTATE '20206' set message_text="paid can not be -ve";
	end if;

	if (new.pending<0) then
		signal SQLSTATE '20207' set message_text="pending can not be -ve";
	end if;

	if (new.paid is null) and (new.pending is null) then
		signal SQLSTATE '20208' set message_text="paid and pending can not be null at the same time";
	end if;

end $$

delimiter ;
