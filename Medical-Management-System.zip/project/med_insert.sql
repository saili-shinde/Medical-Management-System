use db_medical;
delimiter $$

drop procedure if exists med_insert $$

create procedure if not exists med_insert(id int,name varchar(100),avbl int,pc decimal(10,2))
begin
declare co1 int default 0;
declare co2 int default 0; 
select count(*) into co1 from medicines where (m_id=id) or (med_name=name);
if co1=0 then
	insert into medicines values(id,name,avbl,pc);
else
	signal SQLSTATE '30002' set message_text="medicine id or medicine name already exists";
end if;
end $$

delimiter ;
