use db_medical;
delimiter $$

drop function if exists cstmr_search $$
create function cstmr_search(cn varchar(100)) returns boolean deterministic
begin
	declare ck boolean default false;
	declare co int default 0;
	select count(*) into co from customers where c_name=cn;
	if co!=0 then
		set ck = true;
	end if;
return ck;
end $$

delimiter ;
