use db_medical;
delimiter $$

drop function if exists med_search $$
create function med_search(mn varchar(100)) returns boolean deterministic
begin
	declare ck boolean default false;
	declare co int default 0;
	select count(*) into co from medicines where med_name=mn;
	if co!=0 then
		set ck = true;
	end if;
return ck;
end $$

delimiter ;
