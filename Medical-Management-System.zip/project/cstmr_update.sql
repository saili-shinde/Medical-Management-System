use db_medical;
delimiter $$

drop procedure if exists cstmr_update $$

create procedure if not exists cstmr_update(id int,name varchar(100),cntct varchar(20),mn varchar(100),q int,pd float,pen float)
begin 
	declare co int default 0;
	select count(*) into co from customers where (c_id=id) and (med_name=mn) and (quantity=q);
	if co!=0 then
		if q>0 then
		update customers set c_name=name,c_contact=cntct,paid=pd,pending=pen where (c_id=id);
		else
			signal SQLSTATE '30002' set message_text="quantity can not be -ve";
		end if;
	else
		signal SQLSTATE '30002' set message_text="wrong customer id/medicine name/quantity";
	end if;
end $$

delimiter ;
