use db_medical;

delimiter $$

drop function if exists check_price $$
create function check_price(id int,mn varchar(100),q int,pd float,pen float) returns boolean deterministic
begin
declare ck boolean default false;
declare pc float default 0.0;
declare co1 int default 0;
declare co2 int default 0;
declare co3 int default 0;
select count(*) into co1 from customers where c_id=id;
if co1=0 then
	select count(*) into co2 from medicines where (med_name=mn);
	if co2!=0 then
		select count(*) into co3 from medicines where (med_name=mn) and (availability>=q);
		if q>0 then
			if  co3>0 then
				select price into pc from medicines where med_name=mn;
				set pc=pc*q;
				if (pd=pc) or (pen=pc) or ((pd+pen)=pc) then
					set ck = true;
				else 
					signal SQLSTATE '40001' set message_text="wrong price inserted";
				end if;
			else 
				signal SQLSTATE '30001' set message_text="medicine out of stock";
			end if;
		else
			signal SQLSTATE '40002' set message_text="quantity cannot be -ve or zero";
		end if;
	else
		signal SQLSTATE '40002' set message_text="medicine does not exists";
	end if;
else
	signal SQLSTATE '40002' set message_text="id already exists";
end if;
return ck;
end $$

delimiter ;
