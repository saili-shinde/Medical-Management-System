use db_medical;
delimiter $$

drop procedure if exists cstmr_insert $$

create procedure if not exists cstmr_insert(id int,cnm varchar(100),cntc varchar(20),mnm varchar(100),qnt int,pd float,pen float)
begin 

	insert into customers values(id,cnm,cntc,mnm,qnt,pd,pen);
	update medicines set availability=availability-qnt where med_name=mnm;

end $$

delimiter ;
