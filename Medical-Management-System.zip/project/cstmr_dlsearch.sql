use db_medical;
delimiter $$

drop function if exists cstmr_dlsearch $$
create function cstmr_dlsearch(ci int) returns boolean deterministic
begin
	declare ck boolean default false;
	declare co int default 0;
	select count(*) into co from customers where c_id=ci;
	if co!=0 then
		set ck = true;
	end if;
return ck;
end $$

delimiter ;
