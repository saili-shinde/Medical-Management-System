use db_medical;
delimiter $$

drop procedure if exists med_update $$

create procedure if not exists med_update(mi int,name varchar(100),avbl int,pc float)
begin 
	declare co int default 0;
if avbl>0 then
	select count(*) into co from medicines where (med_name=name) and (m_id=mi);
	if co!=0 then
		update medicines set availability=availability+avbl,price=pc where med_name=name;
	else
		signal SQLSTATE '30003' set message_text="wrong medicine id / medicine name";
	end if;
else 
	signal SQLSTATE '30003' set message_text="avability cannot be -ve";
end if;
end $$

delimiter ;
